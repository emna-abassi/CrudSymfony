<?php

namespace App\Repository;

use App\Entity\Crudd;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Crudd|null find($id, $lockMode = null, $lockVersion = null)
 * @method Crudd|null findOneBy(array $criteria, array $orderBy = null)
 * @method Crudd[]    findAll()
 * @method Crudd[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class CruddRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Crudd::class);
    }

    // /**
    //  * @return Crudd[] Returns an array of Crudd objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('c.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Crudd
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
